﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;
using UnityEngine.UI;                               // Using Unity "UI" Namespace

public class MixBusPanelHandler : MonoBehaviour
{
    // joa -> Code to get the UISliders for remote updates...
    private int numSliders = 3;     // we get this from Array.Length anyway...but helpful to keep indexes organized
    static byte MASTERVOLUME = 0;
    static byte MASTERLPFREQUENCY = 1;
    static byte MASTERLPRESONANCE = 2;


    // joa -> Array of Slider Objects filled with GetComponentsInChildren<Slider>() in Awake()
    public Slider[]  mixBusSliders;
    // - OR use a List and foreach technique like we will do with "LPFStepper" ...Level_1 Concept
    //List<Slider> MixBusSliders = new List<Slider>();

    private void Awake()
    {
        // joa -> just use array and direct element access by index defines above
        // DO THIS ON AWAKE TO PREVENT MIXER UPDATE CALLS WITHOUT THE ARRAY BEING VALID
        mixBusSliders = GetComponentsInChildren<Slider>();
        numSliders = mixBusSliders.Length;
        print("Retreived number of sliders: " +  numSliders);

    }

    public void UpdateAllMasterSliders(float a, float b, float c)
    {
        mixBusSliders[MASTERVOLUME].value = a;
        mixBusSliders[MASTERLPFREQUENCY].value = b;
        mixBusSliders[MASTERLPRESONANCE].value = c;
    }

  // joa -> Not animating LPFResonance with our LFO, but of course same technique can be used for any UISlider for updates from other classes  
  public void UpdateMasterLPFrequencySlider(float f)
  {
        mixBusSliders[MASTERLPFREQUENCY].value = f;
  }



}
