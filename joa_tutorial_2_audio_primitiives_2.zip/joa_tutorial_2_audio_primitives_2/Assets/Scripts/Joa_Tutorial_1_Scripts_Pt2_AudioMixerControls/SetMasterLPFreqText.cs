﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;
using UnityEngine.UI;

// joa -> This needs to be attached to Empty GameObject with its Text var assigned by Dragging particular UIText Object to 
// Editor filed for Text...there are different methods in Unity to do this FindObjectsByType()/GetComponent() create Arrays of UIText components etc

public class SetMasterLPFreqText : MonoBehaviour
{
    public Text text;

    public void updateMasterLPFreqText(float f)
    {
        text.text = f.ToString("F2");
    }

}
