﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

public class MotionOscillator_v1 : MonoBehaviour
{

    // joa -> Variables for Oscillator control
    [SerializeField] bool oscillatorOn = true;
    // -> Serialize Vector3 parms for Oscillation - default to X,Y,Z motion with 2 second period
    [Header("Vector3 for Oscillation")]  
    [Tooltip("Play with these to alter 3D Oscillation")][SerializeField] Vector3 osc1_Vect = new Vector3(10f, 10f, 10f);
    // -> Period for Oscillation 0.01->5.0 seconds
    [Tooltip("Period in Seconds")][Range(0.01f,5f)] [SerializeField] float osc1_Period = 2f;    // Init to 2 seconds

    // -> for "depth" factor of motion oscillation
    [Range(0,1)][SerializeField] float depthFactor = .5f;    // Range 0-1 movement depth factor

    // -> Use flag for Uni/Bi-Polar oscillation choice - default to UniPolar, override with PreFab
    [SerializeField] bool biPolarFlag = false;

    // -> Variable for "actual" oscillator depth given scaling with depthFactor parm
    float myDepth;

    // -> Private member for Start position - needed for Absolute/basis movement
    private Vector3 startPos; 

    // Start is called before the first frame update
    void Start()
    {
        // Store the Object start position - via Scene settings - we need this as oscillator origin pos
        startPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if( !oscillatorOn )                         // Bail if we don't want to oscillate
            return;

        // joa -> If the Speed is Zero the Unity transform stuff freaks out - exit on that
        if (osc1_Period <= Mathf.Epsilon)
            return;

        // joa -> Set for Period, Time.time = this frames time in seconds as offset from start of Game - grows continually from t=0 of Start()
        // Time.time IS framerate independent
        float cycles = Time.time / osc1_Period;

        // Get our hook into Radians by using Unity math to get Pi and * 2
        const float tau = Mathf.PI * 2f;
        float rawSine = Mathf.Sin(cycles * tau);   // Goes from -1 to +1

        // We sill scale to 0->1 - todo, make a unipolar version in 
         
        if( biPolarFlag )
            myDepth  = rawSine/2f;   
        else 
            myDepth  = ( rawSine / 2f) + 0.5f;  
 
        // joa -> Use our depthFactor var as scalar
        myDepth *= depthFactor;
        // Then update/scale given depth value - multiply depth * Osc's Vector3 "osc1_Vect" in Editor  
        Vector3 offset = myDepth * osc1_Vect;
        // Then apply to Object position - simple vect math
        transform.position = startPos + offset;

    }
}
