﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

public class UpdateTextMesh : MonoBehaviour
{
    // joa-> TextMesh Child Object can also be dragged into the field this creates on the Editor
    // However see GetComponent<TextMesh>() called on Start(), this will get it automatically
    // There are various ways of doing this, including filling and Array[] of multiple Components by "Type", "Tag" etc
    // We are only using one TextMesh Child Object so the call in Start() is shown as code example of GetComponent...
    private TextMesh mySndNumText;
    private int sndNum;

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Getting the TextMesh Object for Update method 
        mySndNumText = GetComponent<TextMesh>();
        mySndNumText.text = string.Format("Snd:{0:D}", sndNum);
    }

    // joa -> the Text Updater...
    public void UpdateSndNumTextMesh( int sNum )
    {
        sndNum = sNum;
        mySndNumText.text = string.Format("Snd:{0:D}", sndNum);
    }
}
