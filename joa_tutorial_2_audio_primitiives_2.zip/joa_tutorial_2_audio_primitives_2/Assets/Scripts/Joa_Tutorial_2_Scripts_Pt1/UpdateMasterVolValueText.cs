﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;
using UnityEngine.UI;

public class UpdateMasterVolValueText : MonoBehaviour
{
    public Text text;

    public void updateMasterVolTextValue(float f)
    {
        // joa -> Update using dB
        f =  Mathf.Log(f) * 20;
        text.text = f.ToString("F2");
    }
}
