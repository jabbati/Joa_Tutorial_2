﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;
using UnityEngine.Audio;

public class MultiChannelMixer_V1 : MonoBehaviour
{
// joa -> Attach to this to assigned Audio Mixer Asset
public AudioMixer masterMixer;

public float theMasterVolume = 0.8665f;   // init at -3dB  
public float theBassBusVolume = 0.8665f;    


    // joa -> Awake is called BEFORE START - Many aspects of "MasterBusHandler.cs" just copied into this and modified
    private void Awake()
    {
        // joa -> Level_1 Concept Make this a Singleton (w.o Statics)
        // ...if there is more than one of "this"/me, "Destroy" myself
        // ...else Destroy(Object) that is the new instance...
        int numMasterBusHandlers = FindObjectsOfType<MasterBusHandler>().Length; // Remember this method returns an array of existing Objects of this 'Type'

        if (numMasterBusHandlers > 1) 
        {
            Destroy(gameObject);   // gameObject is "This" (Instance)
            print("DENIED REQUEST FOR THE MASTERBUSHANDLER SINGLETON");
        }
        else 
        {
            DontDestroyOnLoad(gameObject); // gameObject is THIS 
            print("MADE THE MASTERBUSHANDLER SINGLETON");
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Set with defaults 
        SetMasterVolume(theMasterVolume);     
        SetBassBusVolume(theBassBusVolume);

    }

    public void SetMasterVolume(float vol)
    {
        // joa -> send using the "Exposed Nanme" of the Audio Mixer Asset component
        // Unity Mixer Range is -80 to 0 (approximate to .001 thru 1.0 and use Log to compensate for dB  non-linearity)
        masterMixer.SetFloat ("masterVolume", Mathf.Log(vol) *20);
    }

    public void SetBassBusVolume(float vol)
    {
        // joa -> send using the "Exposed Nanme" of the Audio Mixer Asset component
        // Unity Mixer Range is -80 to 0 (approximate to .001 thru 1.0 and use Log to compensate for dB  non-linearity)
        masterMixer.SetFloat ("bassBusVolume", Mathf.Log(vol) *20);
    }

    public void SetBassLPFResonance(float val)
    {
        masterMixer.SetFloat( "bassLPFResonance", val);
    }

    public void SetBassBusLPFValue( float freq)
    {
        masterMixer.SetFloat( "bassLPFCutoff", freq);
    }

    // Update is called once per frame
    //void Update()
    //{     
    //}
}
