﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine.UI;
using UnityEngine;

public class PanelSubDivHandler : MonoBehaviour
{

    // joa -> We will want to make an Array of the Buttons we want to Update/Manage
    private Button[] panelSubDivButtons;   

    // -> maybe I am "OldSchool" static int, indexes for the Buttons - they go in top down order of Hierachy...
    static int QUARTER_NOTE = 0;    
    static int EIGHTH_NOTE = 1;
    static int TWELVE_NOTE = 2;
    static int SIXTEEN_NOTE = 3;
    static int TWENTYFOUR_NOTE = 4;

    public int numButtons = 0;

    private ColorBlock myColors;

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Retrieve all the Buttons that are Children of GO "Holder"
        panelSubDivButtons = GetComponentsInChildren<Button>();
        print("Retreived number of Bottons: " +  panelSubDivButtons.Length);
        numButtons = panelSubDivButtons.Length;

        // joa -> Get the Editor settings for Button Color - ASSUMES ALL WILL BE THE SAME SET
        //myColors = this.GetComponent<Button>().colors = The First Child Button
        myColors = panelSubDivButtons[0].colors;        // also = The First Child Button

        SetSubDivButtonStates(SIXTEEN_NOTE);         // default to 16th note
        
    }

    // joa -> My hack to have a set of Buttons act like a multi-Toggle, relies on Color management
    public void SetSubDivButtonStates(int subDiv)
    {
        // -> Check if out of Array Bounds
        if( subDiv<0 || subDiv>=numButtons)
        {
            print("BAD BUTTON INDEX FOR SUBDIVISION");
            return;
        }

        for( int i=0; i<numButtons; i++ )
        {
            if( i == subDiv)
            {
           // panelSubDivButtons[i].colors = myColors.pressedColor;   // leave the active button with "pressed" Color
            SetButtonColor(myColors.pressedColor,i );
            }
            else
            {
                SetButtonColor(myColors.normalColor,i );
            }
        }       
    }

    public void SetButtonColor( Color col, int buttonIndex)
    {
        // joa -> get the editor colors 
        ColorBlock cb = panelSubDivButtons[buttonIndex].colors;

        // -> Override the defaults with color States so only active SubDiv Button is colored
        cb.normalColor = col;

        panelSubDivButtons[buttonIndex].colors = cb;

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
