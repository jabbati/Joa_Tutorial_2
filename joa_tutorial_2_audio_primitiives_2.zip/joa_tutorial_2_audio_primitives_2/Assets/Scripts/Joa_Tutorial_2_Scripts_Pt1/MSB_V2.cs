﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;

public class MSB_V2 : MonoBehaviour
{

    // joa -> This time we will encapulate all of the needed functionality of the multisound/monosound block
    // Control will be done from a central Transport/Sequencer - many optios for interfacing with block elements
    // for musical use, add actual objects for control to the Prefab OR talk to MSB_V2 instances remotely...
    // *Actual playback will be managed by Sequencer - IT will have all of the clips and AudioSource talking to 
    // new Bus in AudioMixer for Bass
    [Header("Block State Variables")] 
    [Tooltip("Playing??")][SerializeField] public bool isActive = false;
    [Tooltip("Pitch Scale")] [SerializeField] public float myPitchScale = 1.0f;

    // joa -> add a filter parm per/block
    public float myLPFValue = 22000;

    [Tooltip("Color for Active")] [SerializeField] public Color onColor;
    [Tooltip("Color for NOT Active")] [SerializeField] public Color offColor;

    // joa -> since this is a Prefab, we can't use the Compnent methods unless they are Actual Comp's of PFab
    // Instead, we will have the Sprites for block as Editor fields - drag and drop Sprites into Prefab instance
    [SerializeField] Sprite[] mySprites;
    // joa -> only one SpriteRenderer used to update waveform Sprites - Could use an Array if more are needed...
    // There is on Sprite GameObject as Child of Prefab, we get its "SpriteRenderer" by "Type" on awake and use to swap Sprites bia sndNum var
    private SpriteRenderer mySpriteRenderer;

    // joa -> Using .scale for visual GUI feedback, so we need to store orig/init Vector3
    Vector3 myScaleTransform;           // Store for refresh

    // joa -> just hardcoded for now - todo add Editor field?
    const  int numSnds = 3;
    [SerializeField] [Range(0, numSnds)]  private int sndNum;

    // joa -> Store Previous and Next Steps in the Sequencer code - they will be needed for more complex sequencing/note control
    public MSB_V2 previousStep, nextStep;

    // Start is called before the first frame update
    void Start()
    {
        // joa -> Level_1 Concept 
        // SEE https://docs.unity3d.com/ScriptReference/Component.GetComponentInChildren.html
        // This relates to the Unity Heirarchy and by using the "...InChidren" version, we assure access to the specific Prefab's Sprite
        // Can be made into array with plural call if we end up with more Sprites in Prefab...
        mySpriteRenderer = GetComponentInChildren<SpriteRenderer>();
        myScaleTransform = this.transform.localScale;
        // Set Editor defaults...
        UpdateBlockStateColor();
        UpdateBlockSprite();

    }

    public bool IsActive() => isActive;     // returns state of block

    public int GetSoundNum() => sndNum;

    public void ToggleIsActive()
    {
        isActive = !isActive;
        UpdateBlockStateColor();
    } 

    // joa -> The general rule to raise by semitone is to multiply the frequency by 1.05946^n, 
    // where n is the number of semitones you want to raise it.
    // -> To lower by semitone is to multiply by 0.9439^n
    public void SetPitchScaleSemitone( float semi)
    {
        if( semi == 0)
        {
            myPitchScale = 1.0f;
            return;
        }
        if(semi>0)     // go up by number of semitones
        {
            myPitchScale = Mathf.Pow(1.05946f, semi);
        }
        else if(semi<0)           // go down by number of semitones
        {
            myPitchScale = Mathf.Pow(0.9439f, Mathf.Abs(semi));
        }
    }

    // joa -> Execution of the .pitch change will be the AudioSource of the Sequencer class of using the Prefab List/Path
    public void SetPitchScale( float scale)
    {
        myPitchScale = scale;
    }

    // joa -> We retrieve pitch on processing of the step in the Sequencer
    public float GetPitchScale() => myPitchScale;

    public void SetFilterValue( float freq)
    {
        // -> Set using direct value...see below for scale base on exponent...(Pow2)
        myLPFValue = freq;
    }

    public void SetFilterValuePow2( float sliderVal)
    {
        // joa -> See Mathf.Pow(f,p) - raise f to power of 2...
        // - I using a Range of 6-148.32 that gives us 36 - 21998.8224 Hz (Unity goes from 10-22k)
        myLPFValue = Mathf.Pow( sliderVal, 2);
    }

    public float GetLPFValue() => myLPFValue;



    public void UpdateBlockSprite()         // make this public in case we want a Global waveform select...
    {
        mySpriteRenderer.sprite = mySprites[sndNum]; 
    }

    public void UpdateBlockStateColor()
    {
        if( isActive )
            ChangeBlockColor( onColor );           
        else
            ChangeBlockColor( offColor );   // "isActive" default to off...
    }

    // joa -> To make this more versatile, I will leave scaleFactor and speed as passed in parms instead of fileds
    public void ScaleBlockDownTimer(float scaleFactor,float speed)        
    {                                                                       
        if(scaleFactor == 0 || speed == 0) 
            return;
        transform.localScale -= new Vector3(scaleFactor, scaleFactor, scaleFactor);
        Invoke("ResetBlockScale", speed);       // joa -> ResetBlockScale timed via Invoke() 
    }

    public void ResetBlockScale()  
    {
           transform.localScale = myScaleTransform;      // joa -> Reset to "myScaleTransform" stored in Start()
    }  

    public void ChangeBlockColor( Color c)
    {
        GetComponent<Renderer>().material.color = c;
    }



    void OnMouseOver()
    {
        // joa -> detect Left-Mouse click here - just cycle through hardcoded number of sounds for now
        // Note that I reversed mouse clicks, left click to set active, right click to change sndNum
        if (Input.GetMouseButtonUp(0))
        {
            ToggleIsActive();
            //ScaleBlockDownTimer( 0.25f, 0.25f);   // Testing...
        }
        else if (Input.GetMouseButtonUp(1))                 // detect Right-Mouse click here
        {
            sndNum++;
            if(sndNum>numSnds)
                sndNum = 0;
            // joa -> UPDATE SPRITEWAVEFORM GFX
            UpdateBlockSprite();
        }

    }

}
