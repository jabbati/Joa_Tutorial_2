﻿//
//  Code -> Joe Abbati - January, 2020
//
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonoSequencer_V1 : MonoBehaviour
{
    public bool SequencerIsPlaying = false;
    private bool SequencerLoopBackFlag = false;
    // joa ->  "List" of Type "MSB_V2" - Script/Class of Prefab - Objects to Sequence...
    [SerializeField] List<MSB_V2> monoSequence;      // For EDITOR ONLY - Drag set of blocks into "path"

    private int numSteps;

    // joa -> For Tempo/BPM and Subdivision control
    private float BPM = 124.00f;
    [Range(1.0f,8.5f)] [SerializeField] public float stepDivisor = 4.00f; // default to 1/16 notes
    private float stepValue = 0.242f;

    // joa -> Output to Bass Bus...
    private AudioSource myAudioSource;
    
    // mixer access - we execute LPF on busses in the mixer (.pitch at the AudioSource)
    private MultiChannelMixer_V1 myMultiMixer_V1;

    // joa -> flag to keep pre g_ scenes working
    [SerializeField] bool usingMulitMixer;

     // joa -> Make Editor Fields for selecting ENTIRE POOL OF AVAILABLE AUDIOCLIPS THAT CAN BE SEQUENCED
     // They will be indexed by accessing the MSB_V2 List Elements sndNum from MonoSequencer() Coroutine
    [Header("Attach AudioClips")] 
    [SerializeField] AudioClip Sound_0;
    [SerializeField] AudioClip Sound_1;
    [SerializeField] AudioClip Sound_2;
    [SerializeField] AudioClip Sound_3;

    void Start()
    {
        // joa ->  Get the AudioSouce Component for Seq Playback (it's routed to the Bass Bus for this example)
        myAudioSource = GetComponent<AudioSource>();        
        // joa -> Get the MultiChannelMixer_V1 so we can control Bus Effects
        myMultiMixer_V1 = FindObjectOfType<MultiChannelMixer_V1>(); 
        // -> Get the number of Steps in the sequencs (List method)
        numSteps = monoSequence.Count;
        print("Steps = " + numSteps);
        // joa -> Populate the Prev/Next MSB_V2 steps...
        ScanPreviousNextSteps();    
    }

    void ScanPreviousNextSteps()
    {
        // joa -> use this to set the MSB_V2's Prev/Next block - we will want to access for more 
        // elaborate sequencing control..."monoSequence" holds our list of steps/blocks, so just go through it
        // with a wrap around...
        print("Start Step Scan...");
        int i = 0;
        foreach (MSB_V2 step in monoSequence)
        {
            if( i == 0 )                                            // The First Step
            {
                step.previousStep = monoSequence[numSteps-1];
                step.nextStep = monoSequence[i+1];
            }
            else if( i == (numSteps-1) )                            // The Last Step
            {
                step.previousStep = monoSequence[i-1];
                step.nextStep = monoSequence[0];
            }
            else                                                    // All Other Steps
            {
                step.previousStep = monoSequence[i-1];
                step.nextStep = monoSequence[i+1];
            }
            i++;
        }    
        print("Scanned  " + i);
    }

    // joa -> Level_1 Concept IEnumerator For a Co-Routine Timer functionality - "yield" with WaitForSeconds(float) 
    // Gets List passed in as var - STARTS WITH Toggle in MIX BUS PANEL FOR ToggleLPFStepper()
    // The List is the "Path" you drag in via script/Inspector fields
    IEnumerator MonoSequencer(List<MSB_V2> sequence)    
    {
        //print("Starting Sequence...");
        foreach (MSB_V2 step in sequence)    
        {
            //print("Making a Step through Sequence");
            if(step.IsActive() && SequencerIsPlaying)       
            {
                step.ScaleBlockDownTimer( 0.25f, 0.25f);        // joa-> temp playback gui effect
                int sndNum = step.GetSoundNum();
                switch(sndNum)
                {
                    case 0:
                        myAudioSource.clip = Sound_0;
                    break;
                    case 1:
                        myAudioSource.clip = Sound_1;
                    break;
                    case 2:
                        myAudioSource.clip = Sound_2;
                    break;
                    case 3:
                        myAudioSource.clip = Sound_3;
                    break;      

                }
                // joa -> the AudioSource itself is used for pitch
                myAudioSource.pitch = step.GetPitchScale();
                // joa -> the MulitChannelMixer_V1 Component/singleton is going to handle the Bass Bus LPF
                // -> this will break the earlier versions so quick flag hack
                if( usingMulitMixer )
                    myMultiMixer_V1.SetBassBusLPFValue(step.myLPFValue);    // could switch to a getter like the .pitch...
                myAudioSource.volume = 1.0f;                                // joa -> remember volume is handled by mixer bus
                myAudioSource.Play();
            }
            else                                            // joa-> step is not active
            {
                myAudioSource.volume = 0.0f;
            }
            yield return new WaitForSeconds(stepValue);     // Based on BPM and Subdivision
        }
        //print("Ended Sequence...");
        SequencerLoopBackFlag = true;      // Cheap way to control looping

    }

    public void StartMonoSequencer()
    {
        SequencerIsPlaying = true;     
        StartCoroutine(MonoSequencer(monoSequence));     
    }

    public void StopMonoSequencer()
    {
  
        SequencerLoopBackFlag = false;
        SequencerIsPlaying = false;     
        myAudioSource.Stop();
        StopAllCoroutines();
        //StopCoroutine(MonoSequencer(monoSequence));           // joa -> Glitchy for some reason :/ (may be the way I use LoopBackFlag...)
    }
    
     // joa -> Toggle for Start/Stop and flags baggage 
    public void ToggleMonoSequencer()
    {
       if( SequencerIsPlaying )
        {
            StopMonoSequencer(); 
        }
        else
        {
            StartMonoSequencer();           
        }
    }

    // joa -> Update the "yield" time used by the Coroutine that Sequences blocks
    // -> 1=1/4  2=1/8 3=8Trips 4=1/16 6=16Trips -> Use floats to be direct with yield math tod - maybe switch to int and cast
    public void SetSequenceDivisorByFloat( float divider )
    {
        stepDivisor = divider;
        stepValue = (60.0f / BPM) / stepDivisor;       
    }

    public void SetSequenceDivisor16()      // todo - ditch these direct SubDiv methods?
    {
        stepDivisor = 4.00f;
        stepValue = (60.0f / BPM) / stepDivisor;
    }

    public void SetSequenceDivisor8()
    {
        stepDivisor = 2.00f;
        stepValue = (60.0f / BPM) / stepDivisor;
    }

    public float GetSequenceTempo() => BPM;

    public void SetSequenceTempo(float f)
    {
        // joa -> Actual step time not same as tempo set via subdivision ...Divisor_()
        BPM = f;
        stepValue = (60.0f/BPM)/stepDivisor;

    }

    // Update is called once per frame
    void Update()
    {
        // joa -> This will stop the Sequencer at end of a foreach parse
        // I use the LoopBackFlag as a tool for looping through the MonoSequencer Coroutine...
        if( SequencerIsPlaying )
        {
            if (SequencerLoopBackFlag )
            {
                SequencerLoopBackFlag  = false;
                // joa -> Reached of sequence CoRoutine, so Restart it...
                StartMonoSequencer();                   
            }
        }
    }
}
