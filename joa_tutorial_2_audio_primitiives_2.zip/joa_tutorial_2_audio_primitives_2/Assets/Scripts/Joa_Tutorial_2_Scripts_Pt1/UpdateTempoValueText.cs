﻿//
//  Code -> Joe Abbati - January, 2020
//
using UnityEngine;
using UnityEngine.UI;

public class UpdateTempoValueText : MonoBehaviour
{
    public Text text;

    public void updateTempoTextValue(float f)
    {
        text.text = f.ToString("F2");
    }
}
